from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import load_pem_public_key

# Importamos los módulos previamente implementados
# KeyManagementModule, SessionManagementModule, EncryptionModule

# Configuración inicial de Alice y Bob
alice_key_manager = KeyManagementModule()
bob_key_manager = KeyManagementModule()

# Paso 1: Generación de claves públicas
alice_public_key = alice_key_manager.generate_key_pair()
bob_public_key = bob_key_manager.generate_key_pair()

# Intercambio de claves públicas (simulación)
# Alice recibe la clave pública de Bob, y Bob recibe la de Alice
alice_shared_key = alice_key_manager.derive_shared_key(bob_public_key)
bob_shared_key = bob_key_manager.derive_shared_key(alice_public_key)

# Validación: Ambos deben tener la misma clave compartida
assert alice_shared_key == bob_shared_key, "Error: Claves compartidas no coinciden."

# Paso 2: Crear sesión segura
session_manager = SessionManagementModule()
alice_session_token = session_manager.create_session(alice_shared_key)
print(f"Sesión creada para Alice con token: {alice_session_token}")

# Paso 3: Alice cifra un mensaje y lo envía a Bob
message = "Este es un mensaje seguro de Alice para Bob."
alice_encryption_module = EncryptionModule(alice_shared_key)
iv, ciphertext, tag = alice_encryption_module.encrypt_message(message)
print(f"Mensaje cifrado por Alice: {ciphertext.hex()}")

# Paso 4: Bob recibe el mensaje y lo descifra
bob_encryption_module = EncryptionModule(bob_shared_key)
decrypted_message = bob_encryption_module.decrypt_message(iv, ciphertext, tag)
print(f"Mensaje descifrado por Bob: {decrypted_message}")

# Paso 5: Validar integridad y manejo de sesión
is_session_valid = session_manager.validate_session(alice_session_token)
if is_session_valid:
    print("La sesión es válida. Comunicación completada con éxito.")
else:
    print("La sesión ha expirado o no es válida.")
